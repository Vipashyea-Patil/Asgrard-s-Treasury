import type {
  Income,
  Expense,
  Budget,
  SavingsGoal,
  MonthlyData,
} from '@/types';

export const initialIncome: Income[] = [
  {
    id: 'inc-1',
    source: 'Royal Treasury Income',
    category: 'Royal Treasury',
    amount: 85000,
    date: '2026-09-01',
    description: 'Monthly allocation from the royal vault',
  },
  {
    id: 'inc-2',
    source: 'Trade Revenue — Nidavellir',
    category: 'Trade Revenue',
    amount: 42000,
    date: '2026-09-03',
    description: 'Dwarven forge trade goods',
  },
  {
    id: 'inc-3',
    source: 'Tribute from Vanaheim',
    category: 'Tribute',
    amount: 28500,
    date: '2026-09-05',
    description: 'Seasonal tribute from the Vanir',
  },
  {
    id: 'inc-4',
    source: 'Investment Returns — Bifrost Bonds',
    category: 'Investment Returns',
    amount: 18000,
    date: '2026-09-08',
    description: 'Quarterly bond yield',
  },
  {
    id: 'inc-5',
    source: 'Trade Revenue — Alfheim',
    category: 'Trade Revenue',
    amount: 35000,
    date: '2026-09-12',
    description: 'Light-elf artisan exports',
  },
  {
    id: 'inc-6',
    source: 'Royal Treasury Income',
    category: 'Royal Treasury',
    amount: 40000,
    date: '2026-08-01',
    description: 'Prior month allocation',
  },
];

export const initialExpenses: Expense[] = [
  {
    id: 'exp-1',
    title: 'Weapons Procurement',
    category: 'Weapons',
    amount: 27000,
    date: '2026-09-02',
    description: 'New enchanted weaponry for the Einherjar',
  },
  {
    id: 'exp-2',
    title: 'Warrior Salaries',
    category: 'Army',
    amount: 31000,
    date: '2026-09-01',
    description: 'Monthly Einherjar compensation',
  },
  {
    id: 'exp-3',
    title: 'Palace Maintenance',
    category: 'Palace',
    amount: 17000,
    date: '2026-09-04',
    description: 'Gladsheim structural repairs',
  },
  {
    id: 'exp-4',
    title: 'Mjölnir Maintenance',
    category: 'Weapons',
    amount: 6500,
    date: '2026-09-06',
    description: 'Handle re-forging and enchantment renewal',
  },
  {
    id: 'exp-5',
    title: 'Feast Expenses',
    category: 'Food',
    amount: 12400,
    date: '2026-09-07',
    description: 'Great feast of the autumn equinox',
  },
  {
    id: 'exp-6',
    title: 'Valkyrie Training',
    category: 'Army',
    amount: 9800,
    date: '2026-09-09',
    description: 'Advanced aerial combat drills',
  },
  {
    id: 'exp-7',
    title: 'Bifrost Maintenance',
    category: 'Other',
    amount: 8200,
    date: '2026-09-10',
    description: 'Rainbow bridge stabilization',
  },
  {
    id: 'exp-8',
    title: 'Entertainment — Bard Troupe',
    category: 'Entertainment',
    amount: 4500,
    date: '2026-09-11',
    description: 'Court performance season',
  },
  {
    id: 'exp-9',
    title: 'Weapons Procurement',
    category: 'Weapons',
    amount: 14300,
    date: '2026-09-13',
    description: 'Stormbreaker components',
  },
  {
    id: 'exp-10',
    title: 'Palace Maintenance',
    category: 'Palace',
    amount: 6200,
    date: '2026-09-14',
    description: 'Throne room gold leaf restoration',
  },
  {
    id: 'exp-11',
    title: 'Feast Expenses',
    category: 'Food',
    amount: 3800,
    date: '2026-09-15',
    description: 'Weekly council banquet',
  },
  {
    id: 'exp-12',
    title: 'Warrior Salaries',
    category: 'Army',
    amount: 15500,
    date: '2026-08-01',
    description: 'Prior month partial',
  },
];

export const initialBudgets: Budget[] = [
  {
    id: 'bud-1',
    category: 'Weapons',
    limit: 30000,
    month: '2026-09',
  },
  {
    id: 'bud-2',
    category: 'Army',
    limit: 40000,
    month: '2026-09',
  },
  {
    id: 'bud-3',
    category: 'Palace',
    limit: 20000,
    month: '2026-09',
  },
  {
    id: 'bud-4',
    category: 'Food',
    limit: 20000,
    month: '2026-09',
  },
  {
    id: 'bud-5',
    category: 'Entertainment',
    limit: 10000,
    month: '2026-09',
  },
  {
    id: 'bud-6',
    category: 'Other',
    limit: 16000,
    month: '2026-09',
  },
];

export const initialSavingsGoals: SavingsGoal[] = [
  {
    id: 'sav-1',
    name: 'Bifrost Fund',
    targetAmount: 20000,
    currentAmount: 14000,
    deadline: '2027-06-01',
  },
  {
    id: 'sav-2',
    name: 'Mjölnir Upgrade',
    targetAmount: 15000,
    currentAmount: 8500,
    deadline: '2027-01-01',
  },
  {
    id: 'sav-3',
    name: 'Asgard Expansion',
    targetAmount: 50000,
    currentAmount: 5000,
    deadline: '2028-01-01',
  },
  {
    id: 'sav-4',
    name: 'Emergency Vault',
    targetAmount: 15000,
    currentAmount: 15000,
    deadline: '2026-12-01',
  },
];

export const monthlyHistory: MonthlyData[] = [
  { month: 'Mar', income: 195000, expenses: 168000, savings: 27000 },
  { month: 'Apr', income: 210000, expenses: 172000, savings: 38000 },
  { month: 'May', income: 225000, expenses: 165000, savings: 60000 },
  { month: 'Jun', income: 205000, expenses: 178000, savings: 27000 },
  { month: 'Jul', income: 240000, expenses: 175000, savings: 65000 },
  { month: 'Aug', income: 218000, expenses: 168000, savings: 50000 },
  { month: 'Sep', income: 248750, expenses: 182430, savings: 42500 },
];

export const incomeCategories = [
  'Royal Treasury',
  'Trade Revenue',
  'Tribute',
  'Investment Returns',
  'Other',
] as const;

export const expenseCategories = [
  'Palace',
  'Army',
  'Weapons',
  'Food',
  'Entertainment',
  'Other',
] as const;

export interface Advisor {
  name: string;
  role: string;
  icon: string;
  accent: string;
}

export const advisors: Advisor[] = [
  { name: 'Odin', role: 'King & Admin', icon: 'Crown', accent: 'amber' },
  { name: 'Sif', role: 'Budget Advisor', icon: 'Scale', accent: 'emerald' },
  { name: 'Heimdall', role: 'Financial Monitor', icon: 'Eye', accent: 'sky' },
  { name: 'Loki', role: 'Expense Analyst', icon: 'Flame', accent: 'green' },
  { name: 'Freyja', role: 'Savings Advisor', icon: 'Gem', accent: 'pink' },
];
