import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react';
import type {
  Income,
  Expense,
  Budget,
  SavingsGoal,
} from '@/types';
import {
  initialIncome,
  initialExpenses,
  initialBudgets,
  initialSavingsGoals,
} from '@/data/initialData';

interface TreasuryState {
  income: Income[];
  expenses: Expense[];
  budgets: Budget[];
  savingsGoals: SavingsGoal[];
}

interface TreasuryContextValue extends TreasuryState {
  addIncome: (income: Omit<Income, 'id'>) => void;
  updateIncome: (id: string, income: Omit<Income, 'id'>) => void;
  deleteIncome: (id: string) => void;
  addExpense: (expense: Omit<Expense, 'id'>) => void;
  updateExpense: (id: string, expense: Omit<Expense, 'id'>) => void;
  deleteExpense: (id: string) => void;
  addBudget: (budget: Omit<Budget, 'id'>) => void;
  updateBudget: (id: string, budget: Omit<Budget, 'id'>) => void;
  deleteBudget: (id: string) => void;
  addSavingsGoal: (goal: Omit<SavingsGoal, 'id'>) => void;
  updateSavingsGoal: (id: string, goal: Omit<SavingsGoal, 'id'>) => void;
  updateSavingsAmount: (id: string, amount: number) => void;
  deleteSavingsGoal: (id: string) => void;
  resetData: () => void;
}

const STORAGE_KEY = 'asgard-treasury-data';

const defaultState: TreasuryState = {
  income: initialIncome,
  expenses: initialExpenses,
  budgets: initialBudgets,
  savingsGoals: initialSavingsGoals,
};

function loadState(): TreasuryState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        income: parsed.income ?? initialIncome,
        expenses: parsed.expenses ?? initialExpenses,
        budgets: parsed.budgets ?? initialBudgets,
        savingsGoals: parsed.savingsGoals ?? initialSavingsGoals,
      };
    }
  } catch {
    // ignore corrupted storage
  }
  return defaultState;
}

const genId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

const TreasuryContext = createContext<TreasuryContextValue | null>(null);

export function TreasuryProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<TreasuryState>(loadState);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const addIncome = (income: Omit<Income, 'id'>) =>
    setState((s) => ({ ...s, income: [{ ...income, id: genId() }, ...s.income] }));

  const updateIncome = (id: string, income: Omit<Income, 'id'>) =>
    setState((s) => ({
      ...s,
      income: s.income.map((i) => (i.id === id ? { ...income, id } : i)),
    }));

  const deleteIncome = (id: string) =>
    setState((s) => ({ ...s, income: s.income.filter((i) => i.id !== id) }));

  const addExpense = (expense: Omit<Expense, 'id'>) =>
    setState((s) => ({
      ...s,
      expenses: [{ ...expense, id: genId() }, ...s.expenses],
    }));

  const updateExpense = (id: string, expense: Omit<Expense, 'id'>) =>
    setState((s) => ({
      ...s,
      expenses: s.expenses.map((e) => (e.id === id ? { ...expense, id } : e)),
    }));

  const deleteExpense = (id: string) =>
    setState((s) => ({
      ...s,
      expenses: s.expenses.filter((e) => e.id !== id),
    }));

  const addBudget = (budget: Omit<Budget, 'id'>) =>
    setState((s) => ({
      ...s,
      budgets: [...s.budgets.filter((b) => b.category !== budget.category), { ...budget, id: genId() }],
    }));

  const updateBudget = (id: string, budget: Omit<Budget, 'id'>) =>
    setState((s) => ({
      ...s,
      budgets: s.budgets.map((b) => (b.id === id ? { ...budget, id } : b)),
    }));

  const deleteBudget = (id: string) =>
    setState((s) => ({ ...s, budgets: s.budgets.filter((b) => b.id !== id) }));

  const addSavingsGoal = (goal: Omit<SavingsGoal, 'id'>) =>
    setState((s) => ({
      ...s,
      savingsGoals: [...s.savingsGoals, { ...goal, id: genId() }],
    }));

  const updateSavingsGoal = (id: string, goal: Omit<SavingsGoal, 'id'>) =>
    setState((s) => ({
      ...s,
      savingsGoals: s.savingsGoals.map((g) => (g.id === id ? { ...goal, id } : g)),
    }));

  const updateSavingsAmount = (id: string, amount: number) =>
    setState((s) => ({
      ...s,
      savingsGoals: s.savingsGoals.map((g) =>
        g.id === id ? { ...g, currentAmount: Math.max(0, amount) } : g
      ),
    }));

  const deleteSavingsGoal = (id: string) =>
    setState((s) => ({
      ...s,
      savingsGoals: s.savingsGoals.filter((g) => g.id !== id),
    }));

  const resetData = () => setState(defaultState);

  return (
    <TreasuryContext.Provider
      value={{
        ...state,
        addIncome,
        updateIncome,
        deleteIncome,
        addExpense,
        updateExpense,
        deleteExpense,
        addBudget,
        updateBudget,
        deleteBudget,
        addSavingsGoal,
        updateSavingsGoal,
        updateSavingsAmount,
        deleteSavingsGoal,
        resetData,
      }}
    >
      {children}
    </TreasuryContext.Provider>
  );
}

export function useTreasury() {
  const ctx = useContext(TreasuryContext);
  if (!ctx) throw new Error('useTreasury must be used within TreasuryProvider');
  return ctx;
}
