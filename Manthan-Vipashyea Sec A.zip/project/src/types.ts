export type IncomeCategory =
  | 'Royal Treasury'
  | 'Trade Revenue'
  | 'Tribute'
  | 'Investment Returns'
  | 'Other';

export type ExpenseCategory =
  | 'Palace'
  | 'Army'
  | 'Weapons'
  | 'Food'
  | 'Entertainment'
  | 'Other';

export interface Income {
  id: string;
  source: string;
  category: IncomeCategory;
  amount: number;
  date: string;
  description?: string;
}

export interface Expense {
  id: string;
  title: string;
  category: ExpenseCategory;
  amount: number;
  date: string;
  description?: string;
}

export interface Budget {
  id: string;
  category: ExpenseCategory;
  limit: number;
  month: string;
}

export interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline?: string;
}

export interface MonthlyData {
  month: string;
  income: number;
  expenses: number;
  savings: number;
}

export type PageId =
  | 'dashboard'
  | 'income'
  | 'expenses'
  | 'budget'
  | 'savings'
  | 'reports';
