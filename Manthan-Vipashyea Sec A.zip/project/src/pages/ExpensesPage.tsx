import { useState, useMemo } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  Search,
  ArrowDownRight,
} from 'lucide-react';
import { useTreasury } from '@/store/TreasuryContext';
import GlassCard from '@/components/GlassCard';
import Modal from '@/components/Modal';
import { FormField, FormSelect, FormTextarea } from '@/components/FormFields';
import DonutChart from '@/components/charts/DonutChart';
import { formatCurrency, formatDate, totalExpenses, expensesByCategory } from '@/utils/calculations';
import { expenseCategories } from '@/data/initialData';
import type { Expense, ExpenseCategory } from '@/types';

const emptyForm: Omit<Expense, 'id'> = {
  title: '',
  category: 'Palace',
  amount: 0,
  date: new Date().toISOString().slice(0, 10),
  description: '',
};

const categoryColors: Record<string, string> = {
  Palace: '#8b5cf6',
  Army: '#3b82f6',
  Weapons: '#ef4444',
  Food: '#f59e0b',
  Entertainment: '#ec4899',
  Other: '#64748b',
};

export default function ExpensesPage() {
  const { expenses, addExpense, updateExpense, deleteExpense } = useTreasury();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<Omit<Expense, 'id'>>(emptyForm);
  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState<string>('All');

  const tExpenses = totalExpenses(expenses);
  const byCategory = expensesByCategory(expenses);

  const donutData = expenseCategories.map((cat) => ({
    label: cat,
    value: byCategory[cat],
    color: categoryColors[cat],
  }));

  const filtered = useMemo(() => {
    return expenses
      .filter((e) => {
        const matchSearch =
          e.title.toLowerCase().includes(search.toLowerCase()) ||
          e.category.toLowerCase().includes(search.toLowerCase());
        const matchCat = filterCat === 'All' || e.category === filterCat;
        return matchSearch && matchCat;
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [expenses, search, filterCat]);

  const handleAdd = () => {
    setEditingId(null);
    setForm(emptyForm);
    setModalOpen(true);
  };

  const handleEdit = (item: Expense) => {
    setEditingId(item.id);
    setForm({
      title: item.title,
      category: item.category,
      amount: item.amount,
      date: item.date,
      description: item.description ?? '',
    });
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      updateExpense(editingId, form);
    } else {
      addExpense(form);
    }
    setModalOpen(false);
  };

  const handleDelete = (id: string) => {
    deleteExpense(id);
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-amber-200">Expense Management</h2>
          <p className="text-sm text-slate-400">
            Total Expenses: <span className="font-semibold text-red-400">{formatCurrency(tExpenses)}</span>
          </p>
        </div>
        <button
          onClick={handleAdd}
          className="flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-2.5 text-sm font-medium text-amber-300 transition-all hover:bg-amber-500/20 hover:shadow-lg hover:shadow-amber-500/10"
        >
          <Plus size={18} /> Add Expense
        </button>
      </div>

      {/* Analytics */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <GlassCard className="p-5 lg:col-span-1">
          <h3 className="mb-4 text-base font-semibold text-amber-200">Expense Analytics</h3>
          <DonutChart data={donutData} centerLabel="Total" centerValue={formatCurrency(tExpenses)} />
        </GlassCard>

        <div className="grid grid-cols-2 gap-4 lg:col-span-2 lg:grid-cols-3">
          {expenseCategories.map((cat) => {
            const catTotal = byCategory[cat];
            const pct = tExpenses > 0 ? (catTotal / tExpenses) * 100 : 0;
            return (
              <GlassCard key={cat} className="p-4">
                <div className="mb-2 flex items-center gap-2">
                  <div className="h-3 w-3 rounded-sm" style={{ backgroundColor: categoryColors[cat] }} />
                  <span className="text-xs text-slate-400">{cat}</span>
                </div>
                <p className="text-base font-bold text-slate-200 lg:text-lg">{formatCurrency(catTotal)}</p>
                <p className="text-xs text-slate-500">{Math.round(pct)}% of total</p>
              </GlassCard>
            );
          })}
        </div>
      </div>

      {/* Filters */}
      <GlassCard className="p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search expenses..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-lg border border-slate-700/60 bg-slate-950/60 py-2 pl-9 pr-3 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-amber-500/40 focus:ring-1 focus:ring-amber-500/20"
            />
          </div>
          <select
            value={filterCat}
            onChange={(e) => setFilterCat(e.target.value)}
            className="rounded-lg border border-slate-700/60 bg-slate-950/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-amber-500/40"
          >
            <option value="All" className="bg-slate-900">All Categories</option>
            {expenseCategories.map((cat) => (
              <option key={cat} value={cat} className="bg-slate-900">{cat}</option>
            ))}
          </select>
        </div>
      </GlassCard>

      {/* Expense list */}
      <GlassCard className="overflow-hidden">
        <div className="border-b border-amber-500/15 px-5 py-4">
          <h3 className="text-base font-semibold text-amber-200">Expense History</h3>
          <p className="text-xs text-slate-500">{filtered.length} transactions</p>
        </div>
        <div className="divide-y divide-slate-800/50">
          {filtered.length === 0 && (
            <p className="py-12 text-center text-sm text-slate-500">No expense records found.</p>
          )}
          {filtered.map((item) => (
            <div
              key={item.id}
              className="group flex items-center gap-3 px-5 py-3.5 transition-colors hover:bg-slate-800/30"
            >
              <div
                className="flex h-10 w-10 items-center justify-center rounded-lg text-white"
                style={{ backgroundColor: `${categoryColors[item.category]}20`, color: categoryColors[item.category] }}
              >
                <ArrowDownRight size={18} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-slate-200">{item.title}</p>
                <p className="min-w-0 truncate text-xs text-slate-500">
                  {item.category} • {formatDate(item.date)}
                  {item.description ? ` • ${item.description}` : ''}
                </p>
              </div>
              <span className="text-sm font-semibold text-red-400">
                -{formatCurrency(item.amount)}
              </span>
              <div className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                <button
                  onClick={() => handleEdit(item)}
                  className="rounded-md p-1.5 text-slate-400 transition-colors hover:bg-slate-700/50 hover:text-amber-300"
                >
                  <Pencil size={16} />
                </button>
                <button
                  onClick={() => handleDelete(item.id)}
                  className="rounded-md p-1.5 text-slate-400 transition-colors hover:bg-slate-700/50 hover:text-red-400"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Add/Edit Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingId ? 'Edit Expense' : 'Add Expense'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <FormField
            label="Title"
            type="text"
            required
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="e.g. Weapons Procurement"
          />
          <FormSelect
            label="Category"
            options={[...expenseCategories]}
            value={form.category}
            onChange={(e) => setForm({ ...form, category: e.target.value as ExpenseCategory })}
          />
          <FormField
            label="Amount (Gold Coins)"
            type="number"
            required
            min={0}
            value={form.amount || ''}
            onChange={(e) => setForm({ ...form, amount: parseFloat(e.target.value) || 0 })}
            placeholder="0"
          />
          <FormField
            label="Date"
            type="date"
            required
            value={form.date}
            onChange={(e) => setForm({ ...form, date: e.target.value })}
          />
          <FormTextarea
            label="Description (optional)"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="Additional notes..."
          />
          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              className="flex-1 rounded-lg border border-amber-500/30 bg-amber-500/15 px-4 py-2.5 text-sm font-medium text-amber-300 transition-all hover:bg-amber-500/25"
            >
              {editingId ? 'Update' : 'Add'} Expense
            </button>
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="rounded-lg border border-slate-700/60 bg-slate-800/50 px-4 py-2.5 text-sm text-slate-400 transition-colors hover:bg-slate-700/50"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
