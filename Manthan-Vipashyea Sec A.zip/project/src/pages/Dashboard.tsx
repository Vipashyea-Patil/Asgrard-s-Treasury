import {
  TrendingUp,
  TrendingDown,
  Wallet,
  PiggyBank,
  AlertTriangle,
  AlertCircle,
  CheckCircle,
  Info,
  TrendingUp as TrendUp,
  BarChart3,
  Search,
  ArrowUpRight,
  ArrowDownRight,
  type LucideIcon,
} from 'lucide-react';
import { useState, useMemo } from 'react';
import { useTreasury } from '@/store/TreasuryContext';
import KpiCard from '@/components/KpiCard';
import GlassCard from '@/components/GlassCard';
import BarChart from '@/components/charts/BarChart';
import DonutChart from '@/components/charts/DonutChart';
import ProgressBars from '@/components/charts/ProgressBars';
import {
  formatCurrency,
  formatDate,
  totalIncome,
  totalExpenses,
  totalSavings,
  currentBalance,
  expensesByCategory,
  budgetUtilization,
  budgetStatus,
  savingsProgress,
  generateAlerts,
} from '@/utils/calculations';
import { monthlyHistory, expenseCategories } from '@/data/initialData';
import type { PageId } from '@/types';

const alertIcons: Record<string, LucideIcon> = {
  AlertTriangle,
  AlertCircle,
  CheckCircle,
  Info,
  TrendUp,
  Wallet,
  BarChart3,
};

const alertStyles: Record<string, string> = {
  danger: 'border-red-500/30 bg-red-500/5 text-red-300',
  warning: 'border-amber-500/30 bg-amber-500/5 text-amber-300',
  success: 'border-emerald-500/30 bg-emerald-500/5 text-emerald-300',
  info: 'border-sky-500/30 bg-sky-500/5 text-sky-300',
};

const categoryColors: Record<string, string> = {
  Palace: '#8b5cf6',
  Army: '#3b82f6',
  Weapons: '#ef4444',
  Food: '#f59e0b',
  Entertainment: '#ec4899',
  Other: '#64748b',
};

interface DashboardProps {
  onNavigate: (page: PageId) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const { income, expenses, budgets, savingsGoals } = useTreasury();
  const [search, setSearch] = useState('');

  const tIncome = totalIncome(income);
  const tExpenses = totalExpenses(expenses);
  const tSavings = totalSavings(savingsGoals);
  const balance = currentBalance(income, expenses);

  const byCategory = expensesByCategory(expenses);
  const utilization = budgetUtilization(budgets, expenses);
  const alerts = generateAlerts(income, expenses, budgets, savingsGoals);

  const donutData = expenseCategories.map((cat) => ({
    label: cat,
    value: byCategory[cat],
    color: categoryColors[cat],
  }));

  const budgetBars = utilization.map((u) => ({
    category: u.category,
    spent: u.spent,
    limit: u.limit,
    percentage: u.percentage,
  }));

  const allTransactions = useMemo(() => {
    const inc = income.map((i) => ({
      id: i.id,
      title: i.source,
      category: i.category,
      amount: i.amount,
      date: i.date,
      type: 'income' as const,
    }));
    const exp = expenses.map((e) => ({
      id: e.id,
      title: e.title,
      category: e.category,
      amount: e.amount,
      date: e.date,
      type: 'expense' as const,
    }));
    const combined = [...inc, ...exp].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    if (!search) return combined.slice(0, 8);
    return combined
      .filter(
        (t) =>
          t.title.toLowerCase().includes(search.toLowerCase()) ||
          t.category.toLowerCase().includes(search.toLowerCase())
      )
      .slice(0, 8);
  }, [income, expenses, search]);

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard
          title="Total Income"
          value={formatCurrency(tIncome)}
          icon={TrendingUp}
          changePercent={12.5}
          comparisonText="vs last month"
          accent="emerald"
        />
        <KpiCard
          title="Total Expenses"
          value={formatCurrency(tExpenses)}
          icon={TrendingDown}
          changePercent={8.2}
          comparisonText="vs last month"
          accent="red"
        />
        <KpiCard
          title="Current Balance"
          value={formatCurrency(balance)}
          icon={Wallet}
          changePercent={15.3}
          comparisonText="vs last month"
          accent="amber"
        />
        <KpiCard
          title="Total Savings"
          value={formatCurrency(tSavings)}
          icon={PiggyBank}
          changePercent={6.8}
          comparisonText="vs last month"
          accent="sky"
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Income vs Expense bar chart */}
        <GlassCard className="p-5 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-amber-200">Monthly Income vs Expense</h3>
              <p className="text-xs text-slate-500">7-month financial overview</p>
            </div>
            <button
              onClick={() => onNavigate('reports')}
              className="flex items-center gap-1 text-xs text-amber-400/70 transition-colors hover:text-amber-300"
            >
              View Reports <ArrowUpRight size={14} />
            </button>
          </div>
          <BarChart data={monthlyHistory} />
        </GlassCard>

        {/* Expense category donut */}
        <GlassCard className="p-5">
          <div className="mb-4">
            <h3 className="text-base font-semibold text-amber-200">Expense Distribution</h3>
            <p className="text-xs text-slate-500">By category</p>
          </div>
          <DonutChart data={donutData} centerLabel="Total" centerValue={formatCurrency(tExpenses)} />
        </GlassCard>
      </div>

      {/* Budget + Savings row */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Budget status */}
        <GlassCard className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-amber-200">Budget Status</h3>
              <p className="text-xs text-slate-500">Category utilization</p>
            </div>
            <button
              onClick={() => onNavigate('budget')}
              className="flex items-center gap-1 text-xs text-amber-400/70 transition-colors hover:text-amber-300"
            >
              Manage <ArrowUpRight size={14} />
            </button>
          </div>
          <ProgressBars bars={budgetBars} />
        </GlassCard>

        {/* Savings goals */}
        <GlassCard className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-amber-200">Savings Goals</h3>
              <p className="text-xs text-slate-500">Active goals</p>
            </div>
            <button
              onClick={() => onNavigate('savings')}
              className="flex items-center gap-1 text-xs text-amber-400/70 transition-colors hover:text-amber-300"
            >
              Manage <ArrowUpRight size={14} />
            </button>
          </div>
          <div className="space-y-4">
            {savingsGoals.slice(0, 4).map((goal) => {
              const progress = savingsProgress(goal);
              const isComplete = progress >= 100;
              return (
                <div key={goal.id}>
                  <div className="mb-1.5 flex items-center justify-between">
                    <span className="text-sm font-medium text-slate-300">{goal.name}</span>
                    <span className={`text-xs font-semibold ${isComplete ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {Math.round(progress)}%
                    </span>
                  </div>
                  <div className="mb-1 flex flex-wrap items-center justify-between gap-x-2 gap-y-0.5 text-xs text-slate-500">
                    <span className="min-w-0">{formatCurrency(goal.currentAmount)} / {formatCurrency(goal.targetAmount)}</span>
                    {isComplete && (
                      <span className="flex items-center gap-1 text-emerald-400">
                        <CheckCircle size={12} /> Complete
                      </span>
                    )}
                  </div>
                  <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-800/60">
                    <div
                      className={`h-full rounded-full transition-all duration-700 ${
                        isComplete
                          ? 'bg-gradient-to-r from-emerald-500 to-teal-500'
                          : 'bg-gradient-to-r from-amber-400 to-amber-600'
                      }`}
                      style={{ width: `${Math.min(100, progress)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </GlassCard>
      </div>

      {/* Alerts + Transactions row */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Smart Alerts */}
        <GlassCard className="p-5">
          <div className="mb-4">
            <h3 className="text-base font-semibold text-amber-200">Smart Financial Alerts</h3>
            <p className="text-xs text-slate-500">Automated insights</p>
          </div>
          <div className="space-y-3">
            {alerts.map((alert, i) => {
              const Icon = alertIcons[alert.icon] ?? Info;
              return (
                <div
                  key={i}
                  className={`flex items-start gap-3 rounded-xl border px-4 py-3 ${alertStyles[alert.type]}`}
                >
                  <Icon size={18} className="mt-0.5 shrink-0" />
                  <p className="text-sm">{alert.message}</p>
                </div>
              );
            })}
          </div>
        </GlassCard>

        {/* Recent Transactions */}
        <GlassCard className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-amber-200">Recent Transactions</h3>
              <p className="text-xs text-slate-500">Latest activity</p>
            </div>
          </div>
          <div className="mb-3 relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search transactions..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-lg border border-slate-700/60 bg-slate-950/60 py-2 pl-9 pr-3 text-sm text-slate-100 placeholder-slate-500 outline-none transition-all focus:border-amber-500/40 focus:ring-1 focus:ring-amber-500/20"
            />
          </div>
          <div className="space-y-2">
            {allTransactions.length === 0 && (
              <p className="py-8 text-center text-sm text-slate-500">No transactions found.</p>
            )}
            {allTransactions.map((t) => (
              <div
                key={t.id}
                className="flex items-center gap-3 rounded-lg border border-slate-800/50 bg-slate-900/30 px-3 py-2.5 transition-colors hover:border-amber-500/20 hover:bg-slate-800/40"
              >
                <div
                  className={`flex h-9 w-9 items-center justify-center rounded-lg ${
                    t.type === 'income'
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-red-500/15 text-red-400'
                  }`}
                >
                  {t.type === 'income' ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-slate-200">{t.title}</p>
                  <p className="text-xs text-slate-500">
                    {t.category} • {formatDate(t.date)}
                  </p>
                </div>
                <span
                  className={`text-sm font-semibold ${
                    t.type === 'income' ? 'text-emerald-400' : 'text-red-400'
                  }`}
                >
                  {t.type === 'income' ? '+' : '-'}
                  {formatCurrency(t.amount)}
                </span>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}
