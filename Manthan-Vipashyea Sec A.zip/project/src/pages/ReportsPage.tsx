import { useState } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  PiggyBank,
  Download,
  Calendar,
} from 'lucide-react';
import { useTreasury } from '@/store/TreasuryContext';
import GlassCard from '@/components/GlassCard';
import BarChart from '@/components/charts/BarChart';
import DonutChart from '@/components/charts/DonutChart';
import LineChart from '@/components/charts/LineChart';
import ProgressBars from '@/components/charts/ProgressBars';
import {
  formatCurrency,
  totalIncome,
  totalExpenses,
  totalSavings,
  currentBalance,
  expensesByCategory,
  budgetUtilization,
} from '@/utils/calculations';
import { monthlyHistory, expenseCategories } from '@/data/initialData';

const categoryColors: Record<string, string> = {
  Palace: '#8b5cf6',
  Army: '#3b82f6',
  Weapons: '#ef4444',
  Food: '#f59e0b',
  Entertainment: '#ec4899',
  Other: '#64748b',
};

type ReportPeriod = 'monthly' | 'yearly';

export default function ReportsPage() {
  const { income, expenses, budgets, savingsGoals } = useTreasury();
  const [period, setPeriod] = useState<ReportPeriod>('monthly');

  const tIncome = totalIncome(income);
  const tExpenses = totalExpenses(expenses);
  const tSavings = totalSavings(savingsGoals);
  const balance = currentBalance(income, expenses);

  const byCategory = expensesByCategory(expenses);
  const utilization = budgetUtilization(budgets, expenses);

  const donutData = expenseCategories.map((cat) => ({
    label: cat,
    value: byCategory[cat],
    color: categoryColors[cat],
  }));

  const budgetBars = utilization.map((u) => ({
    category: u.category,
    spent: u.spent,
    limit: u.limit,
    percentage: u.percentage,
  }));

  const savingsRate = tIncome > 0 ? (tSavings / tIncome) * 100 : 0;
  const expenseRate = tIncome > 0 ? (tExpenses / tIncome) * 100 : 0;

  const handleExport = () => {
    const report = {
      period,
      generatedAt: new Date().toISOString(),
      summary: {
        totalIncome: tIncome,
        totalExpenses: tExpenses,
        currentBalance: balance,
        totalSavings: tSavings,
        savingsRate: `${savingsRate.toFixed(1)}%`,
        expenseRate: `${expenseRate.toFixed(1)}%`,
      },
      expensesByCategory: byCategory,
      budgets: utilization,
      savingsGoals: savingsGoals.map((g) => ({
        name: g.name,
        current: g.currentAmount,
        target: g.targetAmount,
        progress: `${((g.currentAmount / g.targetAmount) * 100).toFixed(1)}%`,
      })),
    };
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `asgard-treasury-report-${period}-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-amber-200">Financial Reports</h2>
          <p className="text-sm text-slate-400">Comprehensive financial analysis</p>
        </div>
        <div className="flex items-center gap-3">
          {/* Period toggle */}
          <div className="flex rounded-lg border border-slate-700/60 bg-slate-950/60 p-1">
            <button
              onClick={() => setPeriod('monthly')}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-all ${
                period === 'monthly'
                  ? 'bg-amber-500/20 text-amber-300'
                  : 'text-slate-400 hover:text-amber-200'
              }`}
            >
              <Calendar size={14} /> Monthly
            </button>
            <button
              onClick={() => setPeriod('yearly')}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-all ${
                period === 'yearly'
                  ? 'bg-amber-500/20 text-amber-300'
                  : 'text-slate-400 hover:text-amber-200'
              }`}
            >
              <Calendar size={14} /> Yearly
            </button>
          </div>
          <button
            onClick={handleExport}
            className="flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-2 text-sm font-medium text-amber-300 transition-all hover:bg-amber-500/20"
          >
            <Download size={16} /> Export
          </button>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <GlassCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400">
              <TrendingUp size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500">Total Income</p>
              <p className="text-sm font-bold text-slate-100 lg:text-lg">{formatCurrency(tIncome)}</p>
            </div>
          </div>
        </GlassCard>
        <GlassCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-500/15 text-red-400">
              <TrendingDown size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500">Total Expenses</p>
              <p className="text-sm font-bold text-slate-100 lg:text-lg">{formatCurrency(tExpenses)}</p>
            </div>
          </div>
        </GlassCard>
        <GlassCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-500/15 text-amber-400">
              <Wallet size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500">Net Balance</p>
              <p className="text-sm font-bold text-slate-100 lg:text-lg">{formatCurrency(balance)}</p>
            </div>
          </div>
        </GlassCard>
        <GlassCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-sky-500/15 text-sky-400">
              <PiggyBank size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500">Total Savings</p>
              <p className="text-sm font-bold text-slate-100 lg:text-lg">{formatCurrency(tSavings)}</p>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Income vs Expense chart */}
      <GlassCard className="p-5">
        <div className="mb-4">
          <h3 className="text-base font-semibold text-amber-200">
            {period === 'monthly' ? 'Monthly' : 'Yearly'} Income vs Expense
          </h3>
          <p className="text-xs text-slate-500">7-month financial trend</p>
        </div>
        <BarChart data={monthlyHistory} />
      </GlassCard>

      {/* Two-column charts */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Expense category chart */}
        <GlassCard className="p-5">
          <div className="mb-4">
            <h3 className="text-base font-semibold text-amber-200">Category-wise Expenses</h3>
            <p className="text-xs text-slate-500">Distribution breakdown</p>
          </div>
          <DonutChart data={donutData} centerLabel="Total" centerValue={formatCurrency(tExpenses)} />
        </GlassCard>

        {/* Savings trend */}
        <GlassCard className="p-5">
          <div className="mb-4">
            <h3 className="text-base font-semibold text-amber-200">Savings Trend</h3>
            <p className="text-xs text-slate-500">Monthly savings progression</p>
          </div>
          <LineChart data={monthlyHistory} metric="savings" />
        </GlassCard>
      </div>

      {/* Budget utilization */}
      <GlassCard className="p-5">
        <div className="mb-4">
          <h3 className="text-base font-semibold text-amber-200">Budget Utilization Report</h3>
          <p className="text-xs text-slate-500">Category spending vs limits</p>
        </div>
        <ProgressBars bars={budgetBars} />
      </GlassCard>

      {/* Key metrics */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <GlassCard className="p-5">
          <h3 className="mb-2 text-sm font-semibold text-amber-200">Savings Rate</h3>
          <p className="text-3xl font-bold text-emerald-400">{savingsRate.toFixed(1)}%</p>
          <p className="mt-1 text-xs text-slate-500">of total income saved</p>
        </GlassCard>
        <GlassCard className="p-5">
          <h3 className="mb-2 text-sm font-semibold text-amber-200">Expense Rate</h3>
          <p className="text-3xl font-bold text-red-400">{expenseRate.toFixed(1)}%</p>
          <p className="mt-1 text-xs text-slate-500">of total income spent</p>
        </GlassCard>
        <GlassCard className="p-5">
          <h3 className="mb-2 text-sm font-semibold text-amber-200">Goals Completed</h3>
          <p className="text-3xl font-bold text-amber-300">
            {savingsGoals.filter((g) => g.currentAmount >= g.targetAmount).length}
            <span className="text-lg text-slate-500">/{savingsGoals.length}</span>
          </p>
          <p className="mt-1 text-xs text-slate-500">savings goals achieved</p>
        </GlassCard>
      </div>
    </div>
  );
}
