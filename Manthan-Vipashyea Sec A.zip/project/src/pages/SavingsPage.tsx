import { useState } from 'react';
import { Plus, Pencil, Trash2, PiggyBank, CheckCircle, Target } from 'lucide-react';
import { useTreasury } from '@/store/TreasuryContext';
import GlassCard from '@/components/GlassCard';
import Modal from '@/components/Modal';
import { FormField, FormTextarea } from '@/components/FormFields';
import { formatCurrency, formatDate, totalSavings, savingsProgress } from '@/utils/calculations';
import type { SavingsGoal } from '@/types';

const emptyForm: Omit<SavingsGoal, 'id'> = {
  name: '',
  targetAmount: 0,
  currentAmount: 0,
  deadline: '',
};

export default function SavingsPage() {
  const { savingsGoals, addSavingsGoal, updateSavingsGoal, updateSavingsAmount, deleteSavingsGoal } =
    useTreasury();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<Omit<SavingsGoal, 'id'>>(emptyForm);
  const [updateId, setUpdateId] = useState<string | null>(null);
  const [updateAmount, setUpdateAmount] = useState(0);

  const tSavings = totalSavings(savingsGoals);
  const totalTarget = savingsGoals.reduce((sum, g) => sum + g.targetAmount, 0);
  const overallProgress = totalTarget > 0 ? (tSavings / totalTarget) * 100 : 0;

  const handleAdd = () => {
    setEditingId(null);
    setForm(emptyForm);
    setModalOpen(true);
  };

  const handleEdit = (goal: SavingsGoal) => {
    setEditingId(goal.id);
    setForm({
      name: goal.name,
      targetAmount: goal.targetAmount,
      currentAmount: goal.currentAmount,
      deadline: goal.deadline ?? '',
    });
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      updateSavingsGoal(editingId, form);
    } else {
      addSavingsGoal(form);
    }
    setModalOpen(false);
  };

  const handleUpdateAmount = (id: string) => {
    const goal = savingsGoals.find((g) => g.id === id);
    if (goal) {
      setUpdateId(id);
      setUpdateAmount(goal.currentAmount);
    }
  };

  const handleSubmitAmount = () => {
    if (updateId) {
      updateSavingsAmount(updateId, updateAmount);
      setUpdateId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-amber-200">Savings Goals</h2>
          <p className="text-sm text-slate-400">
            Total Saved: <span className="font-semibold text-sky-400">{formatCurrency(tSavings)}</span>
            {' / '}
            <span className="text-slate-500">{formatCurrency(totalTarget)}</span>
          </p>
        </div>
        <button
          onClick={handleAdd}
          className="flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-2.5 text-sm font-medium text-amber-300 transition-all hover:bg-amber-500/20 hover:shadow-lg hover:shadow-amber-500/10"
        >
          <Plus size={18} /> Add Goal
        </button>
      </div>

      {/* Overall progress */}
      <GlassCard className="p-5">
        <div className="mb-2 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-sky-500/15 text-sky-400">
              <Target size={20} />
            </div>
            <div>
              <h3 className="text-base font-semibold text-amber-200">Overall Savings Progress</h3>
              <p className="text-xs text-slate-500">Across all goals</p>
            </div>
          </div>
          <span className="text-2xl font-bold text-amber-300">{Math.round(overallProgress)}%</span>
        </div>
        <div className="h-3 w-full overflow-hidden rounded-full bg-slate-800/60">
          <div
            className="h-full rounded-full bg-gradient-to-r from-sky-400 via-amber-400 to-amber-600 transition-all duration-700"
            style={{ width: `${Math.min(100, overallProgress)}%` }}
          />
        </div>
      </GlassCard>

      {/* Goal cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
        {savingsGoals.length === 0 && (
          <p className="col-span-full py-12 text-center text-sm text-slate-500">No savings goals yet. Click "Add Goal" to begin.</p>
        )}
        {savingsGoals.map((goal) => {
          const progress = savingsProgress(goal);
          const isComplete = progress >= 100;
          const remaining = goal.targetAmount - goal.currentAmount;

          return (
            <GlassCard key={goal.id} className="group p-5">
              <div className="mb-4 flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                      isComplete
                        ? 'bg-emerald-500/15 text-emerald-400'
                        : 'bg-amber-500/15 text-amber-400'
                    }`}
                  >
                    {isComplete ? <CheckCircle size={20} /> : <PiggyBank size={20} />}
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-slate-200">{goal.name}</h4>
                    {goal.deadline && (
                      <p className="text-xs text-slate-500">Due {formatDate(goal.deadline)}</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                  <button
                    onClick={() => handleEdit(goal)}
                    className="rounded-md p-1.5 text-slate-400 transition-colors hover:bg-slate-700/50 hover:text-amber-300"
                  >
                    <Pencil size={14} />
                  </button>
                  <button
                    onClick={() => deleteSavingsGoal(goal.id)}
                    className="rounded-md p-1.5 text-slate-400 transition-colors hover:bg-slate-700/50 hover:text-red-400"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>

              {/* Amounts */}
              <div className="mb-3 flex items-baseline justify-between">
                <span className="text-2xl font-bold text-amber-300">
                  {formatCurrency(goal.currentAmount)}
                </span>
                <span className="text-sm text-slate-500">
                  / {formatCurrency(goal.targetAmount)}
                </span>
              </div>

              {/* Progress bar */}
              <div className="mb-2 h-2.5 w-full overflow-hidden rounded-full bg-slate-800/60">
                <div
                  className={`h-full rounded-full transition-all duration-700 ${
                    isComplete
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-500'
                      : 'bg-gradient-to-r from-amber-400 to-amber-600'
                  }`}
                  style={{ width: `${Math.min(100, progress)}%` }}
                />
              </div>

              <div className="mb-4 flex items-center justify-between text-xs">
                <span className={isComplete ? 'text-emerald-400' : 'text-amber-400'}>
                  {Math.round(progress)}% complete
                </span>
                <span className={remaining > 0 ? 'text-slate-500' : 'text-emerald-400'}>
                  {remaining > 0 ? `${formatCurrency(remaining)} to go` : 'Goal achieved!'}
                </span>
              </div>

              {/* Update amount */}
              <button
                onClick={() => handleUpdateAmount(goal.id)}
                className="w-full rounded-lg border border-slate-700/60 bg-slate-800/40 py-2 text-xs font-medium text-slate-300 transition-colors hover:border-amber-500/30 hover:text-amber-300"
              >
                Update Saved Amount
              </button>
            </GlassCard>
          );
        })}
      </div>

      {/* Add/Edit Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingId ? 'Edit Savings Goal' : 'Create Savings Goal'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <FormField
            label="Goal Name"
            type="text"
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="e.g. Bifrost Fund"
          />
          <FormField
            label="Target Amount (Gold Coins)"
            type="number"
            required
            min={0}
            value={form.targetAmount || ''}
            onChange={(e) => setForm({ ...form, targetAmount: parseFloat(e.target.value) || 0 })}
            placeholder="0"
          />
          <FormField
            label="Current Saved Amount (Gold Coins)"
            type="number"
            min={0}
            value={form.currentAmount || ''}
            onChange={(e) => setForm({ ...form, currentAmount: parseFloat(e.target.value) || 0 })}
            placeholder="0"
          />
          <FormField
            label="Target Date (optional)"
            type="date"
            value={form.deadline}
            onChange={(e) => setForm({ ...form, deadline: e.target.value })}
          />
          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              className="flex-1 rounded-lg border border-amber-500/30 bg-amber-500/15 px-4 py-2.5 text-sm font-medium text-amber-300 transition-all hover:bg-amber-500/25"
            >
              {editingId ? 'Update' : 'Create'} Goal
            </button>
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="rounded-lg border border-slate-700/60 bg-slate-800/50 px-4 py-2.5 text-sm text-slate-400 transition-colors hover:bg-slate-700/50"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>

      {/* Update Amount Modal */}
      <Modal
        open={updateId !== null}
        onClose={() => setUpdateId(null)}
        title="Update Saved Amount"
      >
        <div className="space-y-4">
          <FormField
            label="New Saved Amount (Gold Coins)"
            type="number"
            min={0}
            value={updateAmount || ''}
            onChange={(e) => setUpdateAmount(parseFloat(e.target.value) || 0)}
            placeholder="0"
          />
          <div className="flex gap-3 pt-2">
            <button
              onClick={handleSubmitAmount}
              className="flex-1 rounded-lg border border-amber-500/30 bg-amber-500/15 px-4 py-2.5 text-sm font-medium text-amber-300 transition-all hover:bg-amber-500/25"
            >
              Update Amount
            </button>
            <button
              onClick={() => setUpdateId(null)}
              className="rounded-lg border border-slate-700/60 bg-slate-800/50 px-4 py-2.5 text-sm text-slate-400 transition-colors hover:bg-slate-700/50"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
