import { useState } from 'react';
import { Plus, Pencil, Trash2, Wallet, AlertTriangle } from 'lucide-react';
import { useTreasury } from '@/store/TreasuryContext';
import GlassCard from '@/components/GlassCard';
import Modal from '@/components/Modal';
import { FormField, FormSelect } from '@/components/FormFields';
import ProgressBars from '@/components/charts/ProgressBars';
import {
  formatCurrency,
  budgetUtilization,
  budgetStatus,
  expensesByCategory,
} from '@/utils/calculations';
import { expenseCategories } from '@/data/initialData';
import type { Budget, ExpenseCategory } from '@/types';

const emptyForm: Omit<Budget, 'id'> = {
  category: 'Palace',
  limit: 0,
  month: '2026-09',
};

export default function BudgetPage() {
  const { budgets, expenses, addBudget, updateBudget, deleteBudget } = useTreasury();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<Omit<Budget, 'id'>>(emptyForm);

  const utilization = budgetUtilization(budgets, expenses);
  const byCategory = expensesByCategory(expenses);

  const totalBudget = budgets.reduce((sum, b) => sum + b.limit, 0);
  const totalSpent = budgets.reduce((sum, b) => sum + byCategory[b.category], 0);
  const totalRemaining = totalBudget - totalSpent;

  const budgetBars = utilization.map((u) => ({
    category: u.category,
    spent: u.spent,
    limit: u.limit,
    percentage: u.percentage,
  }));

  const handleAdd = () => {
    setEditingId(null);
    setForm(emptyForm);
    setModalOpen(true);
  };

  const handleEdit = (budget: Budget) => {
    setEditingId(budget.id);
    setForm({ category: budget.category, limit: budget.limit, month: budget.month });
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      updateBudget(editingId, form);
    } else {
      addBudget(form);
    }
    setModalOpen(false);
  };

  const handleDelete = (id: string) => {
    deleteBudget(id);
  };

  const availableCategories = expenseCategories.filter(
    (cat) => !budgets.some((b) => b.category === cat && b.id !== editingId)
  );

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-amber-200">Budget Management</h2>
          <p className="text-sm text-slate-400">
            Monthly budget allocation and tracking
          </p>
        </div>
        <button
          onClick={handleAdd}
          className="flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-2.5 text-sm font-medium text-amber-300 transition-all hover:bg-amber-500/20 hover:shadow-lg hover:shadow-amber-500/10"
        >
          <Plus size={18} /> Set Budget
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <GlassCard className="p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-500/15 text-amber-400">
              <Wallet size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500">Total Budget</p>
              <p className="text-xl font-bold text-slate-100">{formatCurrency(totalBudget)}</p>
            </div>
          </div>
        </GlassCard>
        <GlassCard className="p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-500/15 text-red-400">
              <AlertTriangle size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500">Total Spent</p>
              <p className="text-xl font-bold text-slate-100">{formatCurrency(totalSpent)}</p>
            </div>
          </div>
        </GlassCard>
        <GlassCard className="p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400">
              <Wallet size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500">Remaining</p>
              <p className={`text-xl font-bold ${totalRemaining >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {formatCurrency(totalRemaining)}
              </p>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Budget utilization overview */}
      <GlassCard className="p-5">
        <h3 className="mb-4 text-base font-semibold text-amber-200">Budget Utilization</h3>
        <ProgressBars bars={budgetBars} />
      </GlassCard>

      {/* Category breakdown */}
      <GlassCard className="overflow-hidden">
        <div className="border-b border-amber-500/15 px-5 py-4">
          <h3 className="text-base font-semibold text-amber-200">Category Budgets</h3>
          <p className="text-xs text-slate-500">Manage individual category limits</p>
        </div>
        <div className="divide-y divide-slate-800/50">
          {budgets.length === 0 && (
            <p className="py-12 text-center text-sm text-slate-500">No budgets set. Click "Set Budget" to begin.</p>
          )}
          {budgets.map((budget) => {
            const spent = byCategory[budget.category];
            const pct = budget.limit > 0 ? (spent / budget.limit) * 100 : 0;
            const status = budgetStatus(pct);
            const remaining = budget.limit - spent;

            return (
              <div
                key={budget.id}
                className="group flex items-center gap-4 px-5 py-4 transition-colors hover:bg-slate-800/30"
              >
                <div className="flex-1">
                  <div className="mb-1 flex flex-wrap items-center justify-between gap-x-3 gap-y-1">
                    <span className="text-sm font-medium text-slate-200">{budget.category}</span>
                    <span className={`shrink-0 text-xs font-semibold ${status.color}`}>
                      {Math.round(pct)}% — {status.label}
                    </span>
                  </div>
                  <div className="mb-1 h-2 w-full overflow-hidden rounded-full bg-slate-800/60">
                    <div
                      className={`h-full rounded-full bg-gradient-to-r ${status.barColor} transition-all duration-500`}
                      style={{ width: `${Math.min(100, pct)}%` }}
                    />
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-0.5 text-xs text-slate-500">
                    <span className="min-w-0">{formatCurrency(spent)} / {formatCurrency(budget.limit)}</span>
                    <span className={remaining >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                      {remaining >= 0 ? `${formatCurrency(remaining)} remaining` : `${formatCurrency(Math.abs(remaining))} over`}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                  <button
                    onClick={() => handleEdit(budget)}
                    className="rounded-md p-1.5 text-slate-400 transition-colors hover:bg-slate-700/50 hover:text-amber-300"
                  >
                    <Pencil size={16} />
                  </button>
                  <button
                    onClick={() => handleDelete(budget.id)}
                    className="rounded-md p-1.5 text-slate-400 transition-colors hover:bg-slate-700/50 hover:text-red-400"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </GlassCard>

      {/* Add/Edit Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingId ? 'Edit Budget' : 'Set Budget'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <FormSelect
            label="Category"
            options={editingId ? [...expenseCategories] : [...availableCategories]}
            value={form.category}
            onChange={(e) => setForm({ ...form, category: e.target.value as ExpenseCategory })}
          />
          <FormField
            label="Budget Limit (Gold Coins)"
            type="number"
            required
            min={0}
            value={form.limit || ''}
            onChange={(e) => setForm({ ...form, limit: parseFloat(e.target.value) || 0 })}
            placeholder="0"
          />
          <FormField
            label="Month"
            type="month"
            required
            value={form.month}
            onChange={(e) => setForm({ ...form, month: e.target.value })}
          />
          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              className="flex-1 rounded-lg border border-amber-500/30 bg-amber-500/15 px-4 py-2.5 text-sm font-medium text-amber-300 transition-all hover:bg-amber-500/25"
            >
              {editingId ? 'Update' : 'Set'} Budget
            </button>
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="rounded-lg border border-slate-700/60 bg-slate-800/50 px-4 py-2.5 text-sm text-slate-400 transition-colors hover:bg-slate-700/50"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
