import { useState } from 'react';
import { TreasuryProvider } from '@/store/TreasuryContext';
import AsgardBackground from '@/components/AsgardBackground';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import Dashboard from '@/pages/Dashboard';
import IncomePage from '@/pages/IncomePage';
import ExpensesPage from '@/pages/ExpensesPage';
import BudgetPage from '@/pages/BudgetPage';
import SavingsPage from '@/pages/SavingsPage';
import ReportsPage from '@/pages/ReportsPage';
import type { PageId } from '@/types';

function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('dashboard');

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard onNavigate={setCurrentPage} />;
      case 'income':
        return <IncomePage />;
      case 'expenses':
        return <ExpensesPage />;
      case 'budget':
        return <BudgetPage />;
      case 'savings':
        return <SavingsPage />;
      case 'reports':
        return <ReportsPage />;
      default:
        return <Dashboard onNavigate={setCurrentPage} />;
    }
  };

  return (
    <TreasuryProvider>
      <AsgardBackground />
      <div className="relative z-10 min-h-screen overflow-x-hidden">
        <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} />
        <main className="px-4 py-6 pt-16 lg:ml-72 lg:px-8 lg:py-8 lg:pt-8">
          <div className="mx-auto max-w-7xl">
            <Header />
            <div className="min-w-0">{renderPage()}</div>
          </div>
        </main>
      </div>
    </TreasuryProvider>
  );
}

export default App;
