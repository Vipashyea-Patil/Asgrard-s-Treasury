import { useState, useEffect, useRef } from 'react';
import type { MonthlyData } from '@/types';
import { formatCurrency } from '@/utils/calculations';

interface BarChartProps {
  data: MonthlyData[];
}

export default function BarChart({ data }: BarChartProps) {
  const [hovered, setHovered] = useState<number | null>(null);
  const [animate, setAnimate] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(600);

  useEffect(() => {
    setAnimate(false);
    const timer = setTimeout(() => setAnimate(true), 50);
    return () => clearTimeout(timer);
  }, [data]);

  useEffect(() => {
    const updateWidth = () => {
      if (containerRef.current) {
        setWidth(containerRef.current.clientWidth);
      }
    };
    updateWidth();
    window.addEventListener('resize', updateWidth);
    return () => window.removeEventListener('resize', updateWidth);
  }, []);

  const maxVal = Math.max(...data.map((d) => Math.max(d.income, d.expenses))) * 1.1;
  const chartHeight = 220;
  const groupWidth = Math.max(50, Math.min(80, width / data.length));
  const barWidth = Math.min(28, groupWidth * 0.38);
  const gap = barWidth * 0.2;
  const chartWidth = data.length * groupWidth;

  return (
    <div ref={containerRef} className="w-full">
      <div className="w-full">
        <svg width={chartWidth} height={chartHeight + 40} viewBox={`0 0 ${chartWidth} ${chartHeight + 40}`} className="w-full" preserveAspectRatio="xMidYMid meet">
          {/* Grid lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((t) => (
            <line
              key={t}
              x1={0}
              y1={chartHeight * t}
              x2={chartWidth}
              y2={chartHeight * t}
              stroke="rgba(148,163,184,0.1)"
              strokeWidth={1}
            />
          ))}

          {data.map((d, i) => {
            const incomeHeight = animate ? (d.income / maxVal) * chartHeight : 0;
            const expenseHeight = animate ? (d.expenses / maxVal) * chartHeight : 0;
            const x = i * groupWidth + (groupWidth - barWidth * 2 - gap) / 2;

            return (
              <g
                key={d.month}
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
                className="cursor-pointer"
              >
                {/* Income bar */}
                <rect
                  x={x}
                  y={chartHeight - incomeHeight}
                  width={barWidth}
                  height={incomeHeight}
                  rx={3}
                  fill="url(#incomeBarGrad)"
                  className="transition-all duration-500"
                  style={{ transitionDelay: `${i * 60}ms` }}
                />
                {/* Expense bar */}
                <rect
                  x={x + barWidth + gap}
                  y={chartHeight - expenseHeight}
                  width={barWidth}
                  height={expenseHeight}
                  rx={3}
                  fill="url(#expenseBarGrad)"
                  className="transition-all duration-500"
                  style={{ transitionDelay: `${i * 60 + 30}ms` }}
                />
                {/* Month label */}
                <text
                  x={x + barWidth + gap / 2}
                  y={chartHeight + 22}
                  textAnchor="middle"
                  className="fill-slate-400 text-xs font-medium"
                >
                  {d.month}
                </text>

                {/* Tooltip */}
                {hovered === i && (
                  <g>
                    <rect
                      x={Math.max(0, x - 8)}
                      y={Math.max(0, chartHeight - incomeHeight - 68)}
                      width={Math.min(groupWidth + 8, chartWidth - Math.max(0, x - 8))}
                      height={62}
                      rx={8}
                      fill="rgba(15,23,42,0.95)"
                      stroke="rgba(218,165,32,0.3)"
                    />
                    <text x={Math.max(4, x - 4)} y={Math.max(14, chartHeight - incomeHeight - 50)} className="fill-amber-300 text-[11px] font-semibold">
                      {d.month}
                    </text>
                    <text x={Math.max(4, x - 4)} y={Math.max(28, chartHeight - incomeHeight - 36)} className="fill-emerald-400 text-[10px]">
                      In: {formatCurrency(d.income)}
                    </text>
                    <text x={Math.max(4, x - 4)} y={Math.max(42, chartHeight - incomeHeight - 22)} className="fill-red-400 text-[10px]">
                      Out: {formatCurrency(d.expenses)}
                    </text>
                  </g>
                )}
              </g>
            );
          })}

          <defs>
            <linearGradient id="incomeBarGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#34d399" />
              <stop offset="100%" stopColor="#059669" />
            </linearGradient>
            <linearGradient id="expenseBarGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f87171" />
              <stop offset="100%" stopColor="#dc2626" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Legend */}
      <div className="mt-3 flex items-center gap-6">
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-sm bg-gradient-to-b from-emerald-400 to-emerald-600" />
          <span className="text-xs text-slate-400">Income</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-sm bg-gradient-to-b from-red-400 to-red-600" />
          <span className="text-xs text-slate-400">Expenses</span>
        </div>
      </div>
    </div>
  );
}
