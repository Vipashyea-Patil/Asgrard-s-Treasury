import { useState, useEffect } from 'react';
import { formatCurrency } from '@/utils/calculations';

interface DonutChartProps {
  data: { label: string; value: number; color: string }[];
  centerLabel?: string;
  centerValue?: string;
}

export default function DonutChart({ data, centerLabel, centerValue }: DonutChartProps) {
  const [hovered, setHovered] = useState<number | null>(null);
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    setAnimate(false);
    const timer = setTimeout(() => setAnimate(true), 50);
    return () => clearTimeout(timer);
  }, [data]);

  const total = data.reduce((sum, d) => sum + d.value, 0);
  const radius = 70;
  const strokeWidth = 22;
  const circumference = 2 * Math.PI * radius;

  let cumulativeOffset = 0;

  return (
    <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-center sm:justify-around">
      <div className="relative shrink-0">
        <svg width={170} height={170} viewBox="0 0 200 200" className="overflow-visible">
          {/* Background ring */}
          <circle
            cx={100}
            cy={100}
            r={radius}
            fill="none"
            stroke="rgba(148,163,184,0.08)"
            strokeWidth={strokeWidth}
          />
          {data.map((d, i) => {
            const fraction = total > 0 ? d.value / total : 0;
            const dashLength = animate ? fraction * circumference : 0;
            const offset = animate ? cumulativeOffset * circumference : 0;
            cumulativeOffset += fraction;

            return (
              <circle
                key={d.label}
                cx={100}
                cy={100}
                r={radius}
                fill="none"
                stroke={d.color}
                strokeWidth={hovered === i ? strokeWidth + 4 : strokeWidth}
                strokeDasharray={`${dashLength} ${circumference}`}
                strokeDashoffset={-offset}
                strokeLinecap="butt"
                transform="rotate(-90 100 100)"
                className="cursor-pointer transition-all duration-500"
                style={{ transitionDelay: `${i * 80}ms` }}
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
              />
            );
          })}
        </svg>
        {/* Center text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {hovered !== null ? (
            <>
              <p className="text-xs font-semibold text-slate-200">{data[hovered].label}</p>
              <p className="text-base font-bold" style={{ color: data[hovered].color }}>
                {formatCurrency(data[hovered].value)}
              </p>
              <p className="text-xs text-slate-500">
                {total > 0 ? Math.round((data[hovered].value / total) * 100) : 0}%
              </p>
            </>
          ) : (
            <>
              <p className="text-xs text-slate-500">{centerLabel ?? 'Total'}</p>
              <p className="text-base font-bold text-amber-300">
                {centerValue ?? formatCurrency(total)}
              </p>
            </>
          )}
        </div>
      </div>

      {/* Legend */}
      <div className="flex w-full min-w-0 flex-col gap-1.5 sm:w-auto">
        {data.map((d, i) => (
          <div
            key={d.label}
            className="flex cursor-pointer items-center gap-2 rounded-lg px-2 py-1 transition-colors hover:bg-slate-800/50"
            onMouseEnter={() => setHovered(i)}
            onMouseLeave={() => setHovered(null)}
          >
            <div className="h-3 w-3 shrink-0 rounded-sm" style={{ backgroundColor: d.color }} />
            <span className="min-w-0 truncate text-sm text-slate-300">{d.label}</span>
            <span className="ml-auto shrink-0 pl-2 text-sm font-medium text-slate-400">
              {formatCurrency(d.value)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
