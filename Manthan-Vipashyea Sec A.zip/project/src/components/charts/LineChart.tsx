import { useState, useEffect, useRef } from 'react';
import type { MonthlyData } from '@/types';

interface LineChartProps {
  data: MonthlyData[];
  metric: 'savings' | 'income' | 'expenses';
  color?: string;
}

const metricColors: Record<string, string> = {
  savings: '#fbbf24',
  income: '#34d399',
  expenses: '#f87171',
};

export default function LineChart({ data, metric, color }: LineChartProps) {
  const [animate, setAnimate] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(520);

  useEffect(() => {
    setAnimate(false);
    const timer = setTimeout(() => setAnimate(true), 50);
    return () => clearTimeout(timer);
  }, [data, metric]);

  useEffect(() => {
    const updateWidth = () => {
      if (containerRef.current) {
        setWidth(containerRef.current.clientWidth);
      }
    };
    updateWidth();
    window.addEventListener('resize', updateWidth);
    return () => window.removeEventListener('resize', updateWidth);
  }, []);

  const strokeColor = color ?? metricColors[metric];
  const values = data.map((d) => d[metric]);
  const maxVal = Math.max(...values) * 1.1;
  const minVal = 0;

  const chartHeight = 200;
  const padding = { top: 20, right: 20, bottom: 30, left: 50 };
  const chartWidth = Math.max(300, width);
  const innerWidth = chartWidth - padding.left - padding.right;
  const innerHeight = chartHeight - padding.top - padding.bottom;

  const points = values.map((v, i) => {
    const x = padding.left + (i / (values.length - 1)) * innerWidth;
    const y = padding.top + innerHeight - ((v - minVal) / (maxVal - minVal)) * innerHeight;
    return { x, y, value: v, month: data[i].month };
  });

  const pathD = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const areaD = `${pathD} L ${points[points.length - 1].x} ${padding.top + innerHeight} L ${points[0].x} ${padding.top + innerHeight} Z`;

  return (
    <div ref={containerRef} className="w-full">
      <svg width={chartWidth} height={chartHeight} viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full" preserveAspectRatio="xMidYMid meet">
        {/* Grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((t) => (
          <line
            key={t}
            x1={padding.left}
            y1={padding.top + innerHeight * t}
            x2={chartWidth - padding.right}
            y2={padding.top + innerHeight * t}
            stroke="rgba(148,163,184,0.08)"
            strokeWidth={1}
          />
        ))}

        {/* Area fill */}
        <path
          d={areaD}
          fill={strokeColor}
          opacity={animate ? 0.12 : 0}
          className="transition-opacity duration-700"
        />

        {/* Line */}
        <path
          d={pathD}
          fill="none"
          stroke={strokeColor}
          strokeWidth={2.5}
          strokeLinecap="round"
          strokeLinejoin="round"
          style={{
            strokeDasharray: 2000,
            strokeDashoffset: animate ? 0 : 2000,
            transition: 'stroke-dashoffset 1s ease-out',
          }}
        />

        {/* Points */}
        {points.map((p, i) => (
          <g key={i}>
            <circle
              cx={p.x}
              cy={p.y}
              r={4}
              fill={strokeColor}
              opacity={animate ? 1 : 0}
              className="transition-opacity duration-300"
              style={{ transitionDelay: `${i * 80 + 500}ms` }}
            />
            <circle cx={p.x} cy={p.y} r={8} fill={strokeColor} opacity={0.15} />
            <text
              x={p.x}
              y={chartHeight - 8}
              textAnchor="middle"
              className="fill-slate-400 text-[10px]"
            >
              {p.month}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}
