import { useState, useEffect } from 'react';
import { formatCurrency } from '@/utils/calculations';

interface BudgetBar {
  category: string;
  spent: number;
  limit: number;
  percentage: number;
}

interface ProgressBarsProps {
  bars: BudgetBar[];
}

export default function ProgressBars({ bars }: ProgressBarsProps) {
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    setAnimate(false);
    const timer = setTimeout(() => setAnimate(true), 50);
    return () => clearTimeout(timer);
  }, [bars]);

  return (
    <div className="space-y-4">
      {bars.map((bar, i) => {
        const isOver = bar.percentage > 100;
        const isNear = bar.percentage >= 80 && bar.percentage <= 100;
        const barColor = isOver
          ? 'from-red-500 to-red-600'
          : isNear
          ? 'from-amber-500 to-orange-500'
          : 'from-emerald-500 to-teal-500';
        const statusLabel = isOver ? 'Over Budget' : isNear ? 'Near Limit' : 'Within Limit';
        const statusColor = isOver ? 'text-red-400' : isNear ? 'text-amber-400' : 'text-emerald-400';

        return (
          <div key={bar.category}>
            <div className="mb-1.5 flex flex-wrap items-center justify-between gap-x-3 gap-y-1">
              <span className="text-sm font-medium text-slate-300">{bar.category}</span>
              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-500">
                  {formatCurrency(bar.spent)} / {formatCurrency(bar.limit)}
                </span>
                <span className={`shrink-0 font-semibold ${statusColor}`}>
                  {Math.round(bar.percentage)}% — {statusLabel}
                </span>
              </div>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-800/60">
              <div
                className={`h-full rounded-full bg-gradient-to-r ${barColor} transition-all duration-700 ease-out`}
                style={{
                  width: animate ? `${Math.min(100, bar.percentage)}%` : '0%',
                  transitionDelay: `${i * 80}ms`,
                }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
