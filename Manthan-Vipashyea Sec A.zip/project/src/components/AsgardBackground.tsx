import { useEffect, useRef } from 'react';

export default function AsgardBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);
    let animationId = 0;

    interface Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      opacity: number;
      twinkle: number;
      isLeaf: boolean;
    }

    let particles: Particle[] = [];

    function initParticles() {
      particles = [];
      const count = Math.min(90, Math.floor((width * height) / 18000));
      for (let i = 0; i < count; i++) {
        const isLeaf = Math.random() < 0.3;
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height * 0.7,
          vx: (Math.random() - 0.5) * (isLeaf ? 0.3 : 0.15),
          vy: -Math.random() * (isLeaf ? 0.5 : 0.3) - 0.05,
          size: isLeaf ? Math.random() * 3 + 1.5 : Math.random() * 2 + 0.5,
          opacity: isLeaf ? Math.random() * 0.6 + 0.3 : Math.random() * 0.4 + 0.15,
          twinkle: Math.random() * Math.PI * 2,
          isLeaf,
        });
      }
    }

    initParticles();

    let lightningTimer = 0;
    let lightningAlpha = 0;
    let nextLightning = 200 + Math.random() * 400;

    function draw() {
      if (!ctx) return;
      ctx.clearRect(0, 0, width, height);

      // Golden particles and leaves
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.twinkle += 0.02;
        if (p.y < -10) {
          p.y = height + 10;
          p.x = Math.random() * width;
        }
        if (p.x < -10) p.x = width + 10;
        if (p.x > width + 10) p.x = -10;

        const twinkleOpacity = p.opacity * (0.5 + 0.5 * Math.sin(p.twinkle));
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        if (p.isLeaf) {
          ctx.fillStyle = `rgba(255, 200, 80, ${twinkleOpacity})`;
          ctx.shadowBlur = 10;
          ctx.shadowColor = 'rgba(255, 200, 80, 0.7)';
        } else {
          ctx.fillStyle = `rgba(218, 165, 32, ${twinkleOpacity})`;
          ctx.shadowBlur = 6;
          ctx.shadowColor = 'rgba(218, 165, 32, 0.6)';
        }
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      // Lightning
      lightningTimer++;
      if (lightningTimer > nextLightning) {
        lightningAlpha = 0.06 + Math.random() * 0.05;
        lightningTimer = 0;
        nextLightning = 300 + Math.random() * 500;
      }
      if (lightningAlpha > 0) {
        const gradient = ctx.createLinearGradient(0, 0, 0, height * 0.6);
        gradient.addColorStop(0, `rgba(180, 200, 255, ${lightningAlpha})`);
        gradient.addColorStop(1, 'rgba(180, 200, 255, 0)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, width, height * 0.6);
        lightningAlpha *= 0.92;
        if (lightningAlpha < 0.005) lightningAlpha = 0;
      }

      animationId = requestAnimationFrame(draw);
    }

    draw();

    function handleResize() {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      initParticles();
    }

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-0 overflow-hidden">
      {/* Base gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0e1a] via-[#0d1120] to-[#060810]" />

      {/* Distant Asgard city silhouette */}
      <svg
        className="absolute bottom-0 left-1/2 w-[100vw] max-w-[1600px] -translate-x-1/2 opacity-[0.12]"
        viewBox="0 0 1600 300"
        fill="none"
        preserveAspectRatio="xMidYMax meet"
      >
        {/* Central palace cluster */}
        <rect x="700" y="120" width="40" height="180" fill="#1a1a2e" />
        <rect x="745" y="80" width="50" height="220" fill="#1a1a2e" />
        <rect x="800" y="100" width="35" height="200" fill="#1a1a2e" />
        <rect x="840" y="60" width="60" height="240" fill="#1a1a2e" />
        <rect x="905" y="90" width="40" height="210" fill="#1a1a2e" />
        <rect x="950" y="110" width="45" height="190" fill="#1a1a2e" />
        {/* Spires */}
        <polygon points="765,80 775,40 785,80" fill="#1a1a2e" />
        <polygon points="855,60 870,15 885,60" fill="#1a1a2e" />
        <polygon points="915,90 925,55 935,90" fill="#1a1a2e" />
        {/* Left buildings */}
        <rect x="450" y="160" width="35" height="140" fill="#1a1a2e" />
        <rect x="490" y="140" width="40" height="160" fill="#1a1a2e" />
        <rect x="535" y="120" width="30" height="180" fill="#1a1a2e" />
        <rect x="570" y="150" width="45" height="150" fill="#1a1a2e" />
        <rect x="620" y="130" width="35" height="170" fill="#1a1a2e" />
        <rect x="660" y="145" width="30" height="155" fill="#1a1a2e" />
        <polygon points="545,120 552,90 559,120" fill="#1a1a2e" />
        <polygon points="632,130 640,100 648,130" fill="#1a1a2e" />
        {/* Right buildings */}
        <rect x="1000" y="150" width="35" height="150" fill="#1a1a2e" />
        <rect x="1040" y="130" width="40" height="170" fill="#1a1a2e" />
        <rect x="1085" y="145" width="30" height="155" fill="#1a1a2e" />
        <rect x="1120" y="120" width="45" height="180" fill="#1a1a2e" />
        <rect x="1170" y="140" width="35" height="160" fill="#1a1a2e" />
        <polygon points="1055,130 1062,95 1069,130" fill="#1a1a2e" />
        <polygon points="1135,120 1145,80 1155,120" fill="#1a1a2e" />
        {/* Far left towers */}
        <rect x="300" y="180" width="25" height="120" fill="#151525" />
        <rect x="330" y="200" width="20" height="100" fill="#151525" />
        <rect x="355" y="175" width="30" height="125" fill="#151525" />
        <rect x="390" y="195" width="25" height="105" fill="#151525" />
        {/* Far right towers */}
        <rect x="1220" y="175" width="30" height="125" fill="#151525" />
        <rect x="1255" y="195" width="25" height="105" fill="#151525" />
        <rect x="1285" y="180" width="20" height="120" fill="#151525" />
        <rect x="1310" y="200" width="25" height="100" fill="#151525" />
        {/* Distant walls */}
        <rect x="200" y="220" width="100" height="80" fill="#101020" />
        <rect x="1340" y="220" width="100" height="80" fill="#101020" />
      </svg>

      {/* Warm golden glow behind tree */}
      <div
        className="absolute left-1/2 top-[-5%] h-[75vh] w-[90vw] -translate-x-1/2 rounded-full opacity-30"
        style={{
          background:
            'radial-gradient(ellipse at center, rgba(218,165,32,0.4) 0%, rgba(218,165,32,0.12) 35%, transparent 70%)',
        }}
      />

      {/* Secondary warmer glow at trunk base */}
      <div
        className="absolute left-1/2 top-[40%] h-[40vh] w-[30vw] -translate-x-1/2 rounded-full opacity-20"
        style={{
          background:
            'radial-gradient(ellipse at center, rgba(255,180,60,0.3) 0%, transparent 60%)',
        }}
      />

      {/* Yggdrasil — World Tree SVG */}
      <svg
        className="absolute left-1/2 top-0 h-[85vh] w-[100vw] max-w-[1500px] -translate-x-1/2 opacity-[0.38]"
        viewBox="0 0 1500 900"
        fill="none"
        preserveAspectRatio="xMidYMin meet"
      >
        {/* === GLOWING LEAF CLUSTERS === */}
        {/* Canopy glow halos */}
        <ellipse cx="750" cy="150" rx="500" ry="120" fill="url(#canopyGlow)" opacity="0.15" />
        <ellipse cx="300" cy="100" rx="180" ry="80" fill="url(#leafGlow1)" opacity="0.12" />
        <ellipse cx="1200" cy="100" rx="180" ry="80" fill="url(#leafGlow1)" opacity="0.12" />
        <ellipse cx="500" cy="180" rx="140" ry="60" fill="url(#leafGlow1)" opacity="0.1" />
        <ellipse cx="1000" cy="180" rx="140" ry="60" fill="url(#leafGlow1)" opacity="0.1" />
        <ellipse cx="150" cy="60" rx="120" ry="50" fill="url(#leafGlow1)" opacity="0.08" />
        <ellipse cx="1350" cy="60" rx="120" ry="50" fill="url(#leafGlow1)" opacity="0.08" />

        {/* Glowing leaf dots scattered across canopy */}
        {[
          [320, 110, 5], [280, 80, 4], [360, 90, 4.5], [250, 50, 3.5], [390, 60, 3],
          [1180, 110, 5], [1220, 80, 4], [1140, 90, 4.5], [1250, 50, 3.5], [1110, 60, 3],
          [500, 190, 4], [470, 160, 3.5], [530, 170, 4], [1000, 190, 4], [1030, 160, 3.5], [970, 170, 4],
          [150, 70, 4], [120, 40, 3], [180, 50, 3.5], [1350, 70, 4], [1380, 40, 3], [1320, 50, 3.5],
          [600, 220, 3.5], [650, 200, 4], [700, 210, 3.5], [800, 220, 3.5], [850, 200, 4], [750, 190, 4.5],
          [430, 230, 3], [1070, 230, 3], [380, 250, 3], [1120, 250, 3],
          [600, 280, 2.5], [900, 280, 2.5], [750, 260, 3],
        ].map(([cx, cy, r], i) => (
          <circle key={`leaf-${i}`} cx={cx} cy={cy} r={r} fill="#ffd966" opacity="0.5">
            <animate
              attributeName="opacity"
              values="0.3;0.7;0.3"
              dur={`${3 + (i % 4)}s`}
              repeatCount="indefinite"
            />
          </circle>
        ))}

        {/* === TRUNK === */}
        {/* Trunk outer glow */}
        <path
          d="M750 900 C740 780 730 650 745 500 C752 420 740 330 748 250 L752 160"
          stroke="url(#trunkGlowGrad)"
          strokeWidth="18"
          strokeLinecap="round"
          opacity="0.15"
          fill="none"
        />
        {/* Main trunk */}
        <path
          d="M750 900 C742 780 735 650 748 500 C754 420 742 330 750 250 L753 160"
          stroke="url(#trunkGrad)"
          strokeWidth="9"
          strokeLinecap="round"
        />
        {/* Trunk inner highlight */}
        <path
          d="M750 900 C748 780 745 650 750 500 C756 420 745 330 750 250 L753 160"
          stroke="url(#trunkHighlight)"
          strokeWidth="4"
          strokeLinecap="round"
          opacity="0.7"
        />
        {/* Trunk bark texture lines */}
        <path d="M748 850 C746 750 744 650 749 500" stroke="#8b6914" strokeWidth="1" opacity="0.3" fill="none" />
        <path d="M752 820 C754 720 756 620 751 500" stroke="#8b6914" strokeWidth="1" opacity="0.25" fill="none" />

        {/* === MAIN BRANCHES (thick) === */}
        {/* Left main branch */}
        <path d="M750 250 C650 220 540 190 420 140 C360 115 300 95 240 70" stroke="url(#branchGrad)" strokeWidth="6" strokeLinecap="round" fill="none" />
        {/* Right main branch */}
        <path d="M750 250 C850 220 960 190 1080 140 C1140 115 1200 95 1260 70" stroke="url(#branchGrad)" strokeWidth="6" strokeLinecap="round" fill="none" />
        {/* Left upper branch */}
        <path d="M750 200 C620 170 500 140 380 80 C320 50 260 30 200 15" stroke="url(#branchGrad)" strokeWidth="5" strokeLinecap="round" opacity="0.9" fill="none" />
        {/* Right upper branch */}
        <path d="M750 200 C880 170 1000 140 1120 80 C1180 50 1240 30 1300 15" stroke="url(#branchGrad)" strokeWidth="5" strokeLinecap="round" opacity="0.9" fill="none" />
        {/* Left mid branch */}
        <path d="M750 320 C640 300 530 270 430 220 C380 195 340 175 300 160" stroke="url(#branchGrad)" strokeWidth="4" strokeLinecap="round" opacity="0.8" fill="none" />
        {/* Right mid branch */}
        <path d="M750 320 C860 300 970 270 1070 220 C1120 195 1160 175 1200 160" stroke="url(#branchGrad)" strokeWidth="4" strokeLinecap="round" opacity="0.8" fill="none" />
        {/* Left lower branch */}
        <path d="M748 400 C670 380 580 360 500 320 C460 300 430 285 400 275" stroke="url(#branchGrad)" strokeWidth="3" strokeLinecap="round" opacity="0.7" fill="none" />
        {/* Right lower branch */}
        <path d="M752 400 C830 380 920 360 1000 320 C1040 300 1070 285 1100 275" stroke="url(#branchGrad)" strokeWidth="3" strokeLinecap="round" opacity="0.7" fill="none" />

        {/* === SUB-BRANCHES === */}
        {/* Left sub-branches */}
        <path d="M420 140 C380 120 340 100 300 80" stroke="url(#branchGrad)" strokeWidth="3" strokeLinecap="round" opacity="0.65" fill="none" />
        <path d="M420 140 C400 110 390 80 380 50" stroke="url(#branchGrad)" strokeWidth="3" strokeLinecap="round" opacity="0.65" fill="none" />
        <path d="M240 70 C200 55 160 40 120 30" stroke="url(#branchGrad)" strokeWidth="2.5" strokeLinecap="round" opacity="0.55" fill="none" />
        <path d="M240 70 C220 45 210 25 200 5" stroke="url(#branchGrad)" strokeWidth="2.5" strokeLinecap="round" opacity="0.55" fill="none" />
        <path d="M380 80 C340 60 300 45 270 30" stroke="url(#branchGrad)" strokeWidth="2.5" strokeLinecap="round" opacity="0.55" fill="none" />
        <path d="M380 80 C360 55 350 30 345 5" stroke="url(#branchGrad)" strokeWidth="2.5" strokeLinecap="round" opacity="0.55" fill="none" />
        <path d="M500 320 C470 295 440 275 410 260" stroke="url(#branchGrad)" strokeWidth="2" strokeLinecap="round" opacity="0.5" fill="none" />
        <path d="M430 220 C400 200 375 185 350 175" stroke="url(#branchGrad)" strokeWidth="2" strokeLinecap="round" opacity="0.5" fill="none" />

        {/* Right sub-branches */}
        <path d="M1080 140 C1120 120 1160 100 1200 80" stroke="url(#branchGrad)" strokeWidth="3" strokeLinecap="round" opacity="0.65" fill="none" />
        <path d="M1080 140 C1100 110 1110 80 1120 50" stroke="url(#branchGrad)" strokeWidth="3" strokeLinecap="round" opacity="0.65" fill="none" />
        <path d="M1260 70 C1300 55 1340 40 1380 30" stroke="url(#branchGrad)" strokeWidth="2.5" strokeLinecap="round" opacity="0.55" fill="none" />
        <path d="M1260 70 C1280 45 1290 25 1300 5" stroke="url(#branchGrad)" strokeWidth="2.5" strokeLinecap="round" opacity="0.55" fill="none" />
        <path d="M1120 80 C1160 60 1200 45 1230 30" stroke="url(#branchGrad)" strokeWidth="2.5" strokeLinecap="round" opacity="0.55" fill="none" />
        <path d="M1120 80 C1140 55 1150 30 1155 5" stroke="url(#branchGrad)" strokeWidth="2.5" strokeLinecap="round" opacity="0.55" fill="none" />
        <path d="M1000 320 C1030 295 1060 275 1090 260" stroke="url(#branchGrad)" strokeWidth="2" strokeLinecap="round" opacity="0.5" fill="none" />
        <path d="M1070 220 C1100 200 1125 185 1150 175" stroke="url(#branchGrad)" strokeWidth="2" strokeLinecap="round" opacity="0.5" fill="none" />

        {/* === FINE TWIGS === */}
        {[
          "M300 80 C280 70 260 60 240 55",
          "M300 80 C290 65 285 50 280 35",
          "M120 30 C100 20 80 15 60 10",
          "M200 5 C190 -5 180 -10 170 -15",
          "M1200 80 C1220 70 1240 60 1260 55",
          "M1200 80 C1210 65 1215 50 1220 35",
          "M1380 30 C1400 20 1420 15 1440 10",
          "M1300 5 C1310 -5 1320 -10 1330 -15",
          "M600 220 C580 210 560 200 540 195",
          "M900 220 C920 210 940 200 960 195",
          "M650 200 C630 185 615 170 600 160",
          "M850 200 C870 185 885 170 900 160",
        ].map((d, i) => (
          <path key={`twig-${i}`} d={d} stroke="#daa520" strokeWidth="1.5" strokeLinecap="round" opacity="0.4" fill="none" />
        ))}

        {/* === ROOTS === */}
        <path d="M750 880 C680 870 580 865 460 860 C400 858 350 855 300 852" stroke="url(#rootGrad)" strokeWidth="4" strokeLinecap="round" opacity="0.35" fill="none" />
        <path d="M750 880 C820 870 920 865 1040 860 C1100 858 1150 855 1200 852" stroke="url(#rootGrad)" strokeWidth="4" strokeLinecap="round" opacity="0.35" fill="none" />
        <path d="M750 885 C700 880 630 875 560 870" stroke="url(#rootGrad)" strokeWidth="3" strokeLinecap="round" opacity="0.3" fill="none" />
        <path d="M750 885 C800 880 870 875 940 870" stroke="url(#rootGrad)" strokeWidth="3" strokeLinecap="round" opacity="0.3" fill="none" />
        <path d="M750 890 C720 888 680 885 640 883" stroke="url(#rootGrad)" strokeWidth="2" strokeLinecap="round" opacity="0.25" fill="none" />
        <path d="M750 890 C780 888 820 885 860 883" stroke="url(#rootGrad)" strokeWidth="2" strokeLinecap="round" opacity="0.25" fill="none" />

        {/* === RUNIC MARKINGS on trunk === */}
        <g opacity="0.25" stroke="#ffd966" strokeWidth="1.5" fill="none">
          {/* Rune 1 */}
          <path d="M745 550 L745 565 M740 555 L750 565 M745 565 L750 575" />
          {/* Rune 2 */}
          <path d="M755 420 L755 435 M750 425 L760 430 M755 430 L750 440 M755 435 L760 440" />
          {/* Rune 3 */}
          <path d="M747 300 L747 315 M742 305 L752 315" />
        </g>

        <defs>
          <linearGradient id="trunkGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#f0c040" stopOpacity="0.95" />
            <stop offset="40%" stopColor="#daa520" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#8b6914" stopOpacity="0.4" />
          </linearGradient>
          <linearGradient id="trunkHighlight" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#ffe580" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#daa520" stopOpacity="0.3" />
          </linearGradient>
          <linearGradient id="trunkGlowGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#ffd966" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#daa520" stopOpacity="0.1" />
          </linearGradient>
          <linearGradient id="branchGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#f0c040" stopOpacity="0.9" />
            <stop offset="50%" stopColor="#daa520" stopOpacity="0.7" />
            <stop offset="100%" stopColor="#daa520" stopOpacity="0.25" />
          </linearGradient>
          <linearGradient id="rootGrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#daa520" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#daa520" stopOpacity="0" />
          </linearGradient>
          <radialGradient id="canopyGlow">
            <stop offset="0%" stopColor="#ffd966" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#ffd966" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="leafGlow1">
            <stop offset="0%" stopColor="#ffe580" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#ffd966" stopOpacity="0" />
          </radialGradient>
        </defs>
      </svg>

      {/* Storm clouds */}
      <div
        className="absolute inset-0 opacity-25"
        style={{
          background:
            'radial-gradient(ellipse 80% 40% at 30% 10%, rgba(30,35,55,0.6) 0%, transparent 60%), radial-gradient(ellipse 60% 30% at 75% 5%, rgba(25,30,50,0.5) 0%, transparent 60%)',
        }}
      />

      {/* Norse pattern borders */}
      <div
        className="absolute left-0 top-0 h-full w-[40px] opacity-10"
        style={{
          background:
            'repeating-linear-gradient(0deg, transparent, transparent 20px, rgba(218,165,32,0.3) 20px, rgba(218,165,32,0.3) 22px)',
        }}
      />
      <div
        className="absolute right-0 top-0 h-full w-[40px] opacity-10"
        style={{
          background:
            'repeating-linear-gradient(0deg, transparent, transparent 20px, rgba(218,165,32,0.3) 20px, rgba(218,165,32,0.3) 22px)',
        }}
      />

      {/* Animated particles canvas */}
      <canvas ref={canvasRef} className="absolute inset-0" />

      {/* Dark overlay for readability — lighter to keep tree visible */}
      <div className="absolute inset-0 bg-black/40" />
    </div>
  );
}
