import { useState } from 'react';
import {
  LayoutDashboard,
  TrendingUp,
  TrendingDown,
  Wallet,
  PiggyBank,
  BarChart3,
  Menu,
  X,
  Crown,
  Scale,
  Eye,
  Flame,
  Gem,
  Zap,
  type LucideIcon,
} from 'lucide-react';
import type { PageId } from '@/types';
import { advisors } from '@/data/initialData';

interface SidebarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
}

const navItems: { id: PageId; label: string; icon: LucideIcon }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'income', label: 'Income', icon: TrendingUp },
  { id: 'expenses', label: 'Expenses', icon: TrendingDown },
  { id: 'budget', label: 'Budget', icon: Wallet },
  { id: 'savings', label: 'Savings', icon: PiggyBank },
  { id: 'reports', label: 'Reports', icon: BarChart3 },
];

const advisorIcons: Record<string, LucideIcon> = {
  Crown,
  Scale,
  Eye,
  Flame,
  Gem,
};

const advisorColors: Record<string, string> = {
  amber: 'from-amber-400 to-amber-600',
  emerald: 'from-emerald-400 to-emerald-600',
  sky: 'from-sky-400 to-sky-600',
  green: 'from-green-400 to-green-600',
  pink: 'from-pink-400 to-pink-600',
};

export default function Sidebar({ currentPage, onNavigate }: SidebarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNavigate = (page: PageId) => {
    onNavigate(page);
    setMobileOpen(false);
  };

  return (
    <>
      {/* Mobile toggle */}
      <button
        onClick={() => setMobileOpen(!mobileOpen)}
        className="fixed left-4 top-4 z-50 flex h-10 w-10 items-center justify-center rounded-lg border border-amber-500/30 bg-slate-900/80 text-amber-400 backdrop-blur-md lg:hidden"
        aria-label="Toggle menu"
      >
        {mobileOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-0 z-40 flex h-full w-72 flex-col border-r border-amber-500/20 bg-slate-950/80 backdrop-blur-xl transition-transform duration-300 lg:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 border-b border-amber-500/15 px-6 py-6">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 shadow-lg shadow-amber-500/30">
            <Zap className="text-slate-950" size={24} fill="currentColor" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-wide text-amber-300">ASGARD</h1>
            <p className="text-xs font-medium tracking-widest text-amber-500/60">TREASURY</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto px-4 py-4">
          <p className="mb-3 px-3 text-xs font-semibold uppercase tracking-widest text-slate-500">
            Navigation
          </p>
          <ul className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = currentPage === item.id;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => handleNavigate(item.id)}
                    className={`group flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-200 ${
                      active
                        ? 'bg-gradient-to-r from-amber-500/20 to-transparent text-amber-300 shadow-[inset_0_0_0_1px_rgba(218,165,32,0.3)]'
                        : 'text-slate-400 hover:bg-slate-800/50 hover:text-amber-200'
                    }`}
                  >
                    <Icon
                      size={18}
                      className={active ? 'text-amber-400' : 'text-slate-500 group-hover:text-amber-300'}
                    />
                    {item.label}
                    {active && (
                      <span className="ml-auto h-1.5 w-1.5 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(218,165,32,0.8)]" />
                    )}
                  </button>
                </li>
              );
            })}
          </ul>

          {/* Advisors */}
          <p className="mb-3 mt-8 px-3 text-xs font-semibold uppercase tracking-widest text-slate-500">
            Asgard Advisors
          </p>
          <ul className="space-y-2">
            {advisors.map((advisor) => {
              const Icon = advisorIcons[advisor.icon] ?? Crown;
              const colorClass = advisorColors[advisor.accent] ?? 'from-amber-400 to-amber-600';
              return (
                <li key={advisor.name}>
                  <div className="group flex cursor-default items-center gap-3 rounded-lg px-3 py-2 transition-all duration-200 hover:bg-slate-800/50">
                    <div
                      className={`flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br ${colorClass} shadow-md transition-transform duration-200 group-hover:scale-110 group-hover:shadow-lg`}
                    >
                      <Icon size={16} className="text-slate-950" />
                    </div>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-slate-300 group-hover:text-amber-200">
                        {advisor.name}
                      </p>
                      <p className="truncate text-xs text-slate-500">{advisor.role}</p>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Footer */}
        <div className="border-t border-amber-500/15 px-6 py-4">
          <p className="text-xs text-slate-600">
            Realm of Asgard
          </p>
          <p className="text-xs text-amber-500/40">Treasury System v1.0</p>
        </div>
      </aside>
    </>
  );
}
