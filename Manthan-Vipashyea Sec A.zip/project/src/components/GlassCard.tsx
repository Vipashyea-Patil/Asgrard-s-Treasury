import type { ReactNode } from 'react';

interface GlassCardProps {
  children: ReactNode;
  className?: string;
}

export default function GlassCard({ children, className = '' }: GlassCardProps) {
  return (
    <div
      className={`rounded-2xl border border-amber-500/15 bg-slate-900/40 backdrop-blur-xl ${className}`}
    >
      {children}
    </div>
  );
}
