import { Zap } from 'lucide-react';

export default function Header() {
  return (
    <header className="relative mb-8">
      <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
        {/* Left side */}
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-amber-300 sm:text-4xl">
            ASGARD TREASURY
          </h1>
          <p className="mt-1 text-sm font-medium tracking-widest text-amber-500/60 uppercase">
            Manage • Plan • Build
          </p>
          <div className="mt-4 flex items-center gap-2">
            <Zap className="text-amber-400" size={20} fill="currentColor" />
            <span className="text-lg text-slate-200">
              Welcome back, Thor <span className="text-amber-400">⚡</span>
            </span>
          </div>
          <p className="mt-1 text-sm italic text-slate-400">
            "Let's make Asgard's gold work smarter."
          </p>
        </div>

        {/* Profile */}
        <div className="flex items-center gap-4 rounded-2xl border border-amber-500/20 bg-slate-900/40 px-5 py-3 backdrop-blur-md">
          <div className="relative">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-amber-600 shadow-lg shadow-amber-500/30">
              <Zap className="text-slate-950" size={24} fill="currentColor" />
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-slate-900 bg-emerald-400" />
          </div>
          <div>
            <p className="text-sm font-semibold text-amber-200">Thor</p>
            <p className="text-xs text-slate-400">Chief Financial Manager</p>
          </div>
        </div>
      </div>
    </header>
  );
}
