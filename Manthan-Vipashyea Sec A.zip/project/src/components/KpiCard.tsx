import type { LucideIcon } from 'lucide-react';

interface KpiCardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  changePercent: number;
  comparisonText: string;
  accent: 'amber' | 'red' | 'emerald' | 'sky';
}

const accentStyles = {
  amber: {
    iconBg: 'from-amber-400/20 to-amber-600/10',
    iconColor: 'text-amber-400',
    glow: 'shadow-[0_0_20px_-5px_rgba(218,165,32,0.3)]',
    border: 'hover:border-amber-500/40',
  },
  red: {
    iconBg: 'from-red-400/20 to-red-600/10',
    iconColor: 'text-red-400',
    glow: 'shadow-[0_0_20px_-5px_rgba(239,68,68,0.3)]',
    border: 'hover:border-red-500/40',
  },
  emerald: {
    iconBg: 'from-emerald-400/20 to-emerald-600/10',
    iconColor: 'text-emerald-400',
    glow: 'shadow-[0_0_20px_-5px_rgba(16,185,129,0.3)]',
    border: 'hover:border-emerald-500/40',
  },
  sky: {
    iconBg: 'from-sky-400/20 to-sky-600/10',
    iconColor: 'text-sky-400',
    glow: 'shadow-[0_0_20px_-5px_rgba(56,189,248,0.3)]',
    border: 'hover:border-sky-500/40',
  },
};

export default function KpiCard({
  title,
  value,
  icon: Icon,
  changePercent,
  comparisonText,
  accent,
}: KpiCardProps) {
  const styles = accentStyles[accent];
  const isPositive = changePercent >= 0;

  return (
    <div
      className={`group relative overflow-hidden rounded-2xl border border-amber-500/15 bg-slate-900/40 p-5 backdrop-blur-xl transition-all duration-300 ${styles.border} hover:shadow-xl ${styles.glow}`}
    >
      {/* Shimmer effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

      <div className="relative flex items-start justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
            {title}
          </p>
          <p className="mt-2 text-xl font-bold leading-tight text-slate-100 sm:text-2xl xl:text-3xl">
            {value}
          </p>
        </div>
        <div
          className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${styles.iconBg} ${styles.iconColor}`}
        >
          <Icon size={24} />
        </div>
      </div>

      <div className="relative mt-4 flex items-center gap-2">
        <span
          className={`flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-semibold ${
            isPositive
              ? 'bg-emerald-500/15 text-emerald-400'
              : 'bg-red-500/15 text-red-400'
          }`}
        >
          {isPositive ? '↑' : '↓'} {Math.abs(changePercent)}%
        </span>
        <span className="text-xs text-slate-500">{comparisonText}</span>
      </div>
    </div>
  );
}
