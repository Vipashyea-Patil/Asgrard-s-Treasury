import type {
  Income,
  Expense,
  Budget,
  SavingsGoal,
  ExpenseCategory,
} from '@/types';

export function formatCurrency(amount: number): string {
  const formatted = new Intl.NumberFormat('en-US', {
    maximumFractionDigits: 0,
  }).format(amount);
  return `${formatted} GC`;
}

export function formatCurrencyDetailed(amount: number): string {
  const formatted = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
  return `${formatted} GC`;
}

export function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function totalIncome(income: Income[]): number {
  return income.reduce((sum, i) => sum + i.amount, 0);
}

export function totalExpenses(expenses: Expense[]): number {
  return expenses.reduce((sum, e) => sum + e.amount, 0);
}

export function totalSavings(goals: SavingsGoal[]): number {
  return goals.reduce((sum, g) => sum + g.currentAmount, 0);
}

export function currentBalance(income: Income[], expenses: Expense[]): number {
  return totalIncome(income) - totalExpenses(expenses);
}

export function expensesByCategory(expenses: Expense[]): Record<ExpenseCategory, number> {
  const result: Record<ExpenseCategory, number> = {
    Palace: 0,
    Army: 0,
    Weapons: 0,
    Food: 0,
    Entertainment: 0,
    Other: 0,
  };
  expenses.forEach((e) => {
    result[e.category] += e.amount;
  });
  return result;
}

export function budgetUtilization(
  budgets: Budget[],
  expenses: Expense[]
): { category: ExpenseCategory; limit: number; spent: number; percentage: number }[] {
  const byCat = expensesByCategory(expenses);
  return budgets.map((b) => ({
    category: b.category,
    limit: b.limit,
    spent: byCat[b.category],
    percentage: b.limit > 0 ? (byCat[b.category] / b.limit) * 100 : 0,
  }));
}

export function budgetStatus(percentage: number): {
  label: string;
  color: string;
  barColor: string;
} {
  if (percentage > 100) {
    return { label: 'Over Budget', color: 'text-red-400', barColor: 'from-red-500 to-red-600' };
  }
  if (percentage >= 80) {
    return { label: 'Near Limit', color: 'text-amber-400', barColor: 'from-amber-500 to-orange-500' };
  }
  return { label: 'Within Limit', color: 'text-emerald-400', barColor: 'from-emerald-500 to-teal-500' };
}

export function savingsProgress(goal: SavingsGoal): number {
  return goal.targetAmount > 0
    ? Math.min(100, (goal.currentAmount / goal.targetAmount) * 100)
    : 0;
}

export function generateAlerts(
  income: Income[],
  expenses: Expense[],
  budgets: Budget[],
  goals: SavingsGoal[]
): { type: 'warning' | 'success' | 'info' | 'danger'; message: string; icon: string }[] {
  const alerts: { type: 'warning' | 'success' | 'info' | 'danger'; message: string; icon: string }[] = [];
  const util = budgetUtilization(budgets, expenses);

  util.forEach((u) => {
    if (u.percentage > 100) {
      alerts.push({
        type: 'danger',
        message: `Asgard has exceeded its ${u.category} budget this month (${Math.round(u.percentage)}%).`,
        icon: 'AlertTriangle',
      });
    } else if (u.percentage >= 80) {
      alerts.push({
        type: 'warning',
        message: `${u.category} spending is nearing its budget limit (${Math.round(u.percentage)}%).`,
        icon: 'AlertCircle',
      });
    }
  });

  goals.forEach((g) => {
    const progress = savingsProgress(g);
    if (progress >= 100) {
      alerts.push({
        type: 'success',
        message: `Your ${g.name} savings goal is fully funded!`,
        icon: 'CheckCircle',
      });
    } else if (progress >= 70) {
      alerts.push({
        type: 'success',
        message: `Your ${g.name} savings goal is ${Math.round(progress)}% complete.`,
        icon: 'TrendingUp',
      });
    } else if (progress <= 15 && g.targetAmount > 10000) {
      alerts.push({
        type: 'info',
        message: `${g.name} needs attention — only ${Math.round(progress)}% saved toward ${formatCurrency(g.targetAmount)}.`,
        icon: 'Info',
      });
    }
  });

  const balance = currentBalance(income, expenses);
  if (balance < 50000) {
    alerts.push({
      type: 'warning',
      message: `Current balance is ${formatCurrency(balance)}. Consider reducing discretionary spending.`,
      icon: 'Wallet',
    });
  }

  const expenseTotal = totalExpenses(expenses);
  const incomeTotal = totalIncome(income);
  if (incomeTotal > 0 && expenseTotal / incomeTotal > 0.7) {
    alerts.push({
      type: 'info',
      message: `Expenses are ${Math.round((expenseTotal / incomeTotal) * 100)}% of income. Monitor spending closely.`,
      icon: 'BarChart3',
    });
  }

  return alerts;
}
